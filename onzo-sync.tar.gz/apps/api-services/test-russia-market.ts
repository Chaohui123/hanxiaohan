import { analyzeProductForRussia } from './src/services/russia-market-rules.js';

console.log('=' .repeat(60));
console.log('🔍 俄罗斯市场选品合规分析测试');
console.log('=' .repeat(60));

const testCases = [
  {
    title: '无线蓝牙耳机 TWS降噪 迷你入耳式耳机',
    category: ['数码', '耳机'],
    weight: 0.15,
    description: '蓝牙5.0 主动降噪 长续航 迷你便携'
  },
  {
    title: '智能手表 多功能运动手环 心率监测 防水',
    category: ['数码', '智能穿戴'],
    weight: 0.25,
    description: '心率监测 睡眠监测 计步器 消息提醒 蓝牙连接'
  },
  {
    title: '便携折叠充电宝 20000mAh 大容量 移动电源',
    category: ['数码', '电源配件'],
    weight: 0.5,
    description: '大容量移动电源 双USB输出 快充 支持手机平板'
  },
  {
    title: 'USB-C快充数据线 编织线 1米 手机充电线',
    category: ['数码', '配件'],
    weight: 0.05,
    description: 'USB Type-C 编织耐用 快充 充电数据传输二合一'
  },
  {
    title: '便携蓝牙音箱 户外防水 重低音 便携式音响',
    category: ['数码', '音箱'],
    weight: 0.4,
    description: '蓝牙5.0 IPX7防水 24小时续航 TWS串联'
  },
  {
    title: '俄罗斯男士羽绒服 保暖加厚 冬季外套',
    category: ['服装', '男装', '羽绒服'],
    weight: 1.5,
    description: '白鸭绒填充 加厚保暖 防风防水 冬季必备'
  },
  {
    title: '女士雪地靴 防滑保暖 加绒加厚 冬季靴子',
    category: ['鞋靴', '女鞋'],
    weight: 1.2,
    description: '防水防寒 毛绒内里 防滑大底 俄罗斯冬季必备'
  },
  {
    title: '玻璃工艺品 水晶摆件 家居装饰花瓶',
    category: ['家居', '装饰'],
    weight: 2.5,
    description: '高档玻璃材质 手工制作 易碎品 需注意包装'
  },
  {
    title: '液体香水 法国香水 女士持久淡香 50ml',
    category: ['美妆', '香水'],
    weight: 0.3,
    description: '法国进口原料 持久淡香 女士香水 液体产品'
  },
  {
    title: '电子烟 加热不燃烧 尼古丁烟油 充电套装',
    category: ['烟具', '电子'],
    weight: 0.2,
    description: '电子烟套装 含烟油 尼古丁产品'
  },
  {
    title: '减肥药 快速燃脂 瘦身胶囊 减肥保健品',
    category: ['保健品', '减肥'],
    weight: 0.15,
    description: '快速燃脂 抑制食欲 减肥胶囊 强效瘦身'
  },
  {
    title: '仿牌运动鞋 耐克同款 阿迪跑鞋 复刻版',
    category: ['鞋靴', '运动'],
    weight: 0.8,
    description: '耐克同款运动鞋 复刻版 高品质仿品'
  },
  {
    title: '多功能电动螺丝刀 充电式电钻 家用工具套装',
    category: ['工具', '电动工具'],
    weight: 3.5,
    description: '锂电充电 多功能 电动螺丝刀 家用维修工具'
  },
  {
    title: '家居收纳盒 塑料整理箱 衣柜收纳神器',
    category: ['家居', '收纳'],
    weight: 0.8,
    description: 'PP材质 可堆叠 防尘收纳 多规格 家居必备'
  },
  {
    title: '汽车行车记录仪 高清夜视 车载记录仪',
    category: ['汽车', '电子设备'],
    weight: 0.5,
    description: '1080P高清 夜视功能 循环录制 车载必备'
  },
  {
    title: '户外帐篷 3-4人野营帐篷 防水防风 便携式',
    category: ['户外', '露营'],
    weight: 3.0,
    description: '双层设计 防水PU涂层 快速搭建 露营必备'
  },
  {
    title: '宠物自动喂食器 定时定量 智能猫狗喂食器',
    category: ['宠物', '智能设备'],
    weight: 1.8,
    description: 'WiFi连接 定时定量 远程控制 智能宠物用品'
  },
  {
    title: '厨房小家电 多功能电饭煲 智能预约',
    category: ['家电', '厨房'],
    weight: 4.5,
    description: '智能电饭煲 大容量 预约功能 多种烹饪模式'
  }
];

console.log('\n📋 测试商品数量:', testCases.length);

let recommendCount = 0;
let considerCount = 0;
let cautionCount = 0;
let rejectCount = 0;

for (let i = 0; i < testCases.length; i++) {
  const testCase = testCases[i];
  console.log(`\n${'─'.repeat(60)}`);
  console.log(`📍 商品 ${i + 1}: ${testCase.title}`);
  console.log(`   分类: ${testCase.category.join(' > ')}`);
  console.log(`   重量: ${testCase.weight}kg`);

  const analysis = analyzeProductForRussia(
    testCase.title,
    testCase.description,
    testCase.category,
    testCase.weight
  );

  let verdict = '';
  if (analysis.isForbidden) {
    verdict = '🚫 禁止销售';
    rejectCount++;
  } else if (analysis.isRestricted && analysis.overallScore < 50) {
    verdict = '⚠️ 高度风险';
    cautionCount++;
  } else if (analysis.isLogisticsRisk) {
    verdict = '📦 物流风险';
    cautionCount++;
  } else if (analysis.overallScore >= 70) {
    verdict = '✅ 推荐';
    recommendCount++;
  } else if (analysis.overallScore >= 50) {
    verdict = '🟢 可考虑';
    considerCount++;
  } else {
    verdict = '❌ 不建议';
    rejectCount++;
  }

  console.log(`   结论: ${verdict} | 综合评分: ${analysis.overallScore}`);
  console.log(`   合规: ${analysis.complianceScore} | 物流: ${analysis.logisticsScore} | 市场: ${analysis.marketScore}`);
  
  if (analysis.riskTags.length > 0) {
    console.log(`   🔖 风险标签: ${analysis.riskTags.join(', ')}`);
  }

  if (analysis.warnings.length > 0) {
    console.log(`   ⚠️ 警告:`);
    analysis.warnings.forEach(w => console.log(`      • ${w}`));
  }

  if (analysis.recommendations.length > 0) {
    console.log(`   💡 建议:`);
    analysis.recommendations.slice(0, 3).forEach(r => console.log(`      • ${r}`));
  }
}

console.log('\n' + '='.repeat(60));
console.log('📊 测试总结');
console.log('='.repeat(60));
console.log(`✅ 推荐: ${recommendCount} 个商品`);
console.log(`🟢 可考虑: ${considerCount} 个商品`);
console.log(`⚠️ 谨慎/风险: ${cautionCount} 个商品`);
console.log(`❌ 禁止/不建议: ${rejectCount} 个商品`);

console.log('\n' + '='.repeat(60));
console.log('📝 俄罗斯市场选品建议总结');
console.log('='.repeat(60));
console.log(`
🎯 **最佳品类（强烈推荐）:**
   • 冬季服装/羽绒服 - 俄罗斯冬季严寒，刚需巨大
   • 鞋靴/雪地靴 - 冬季必备，市场需求稳定
   • 家居收纳 - 俄式住宅特点，收纳需求大
   • 手机数码配件 - 电子产品渗透率高，复购强
   • 汽车用品 - 俄罗斯汽车保有量大，汽配需求旺

⚠️ **高风险品类（需谨慎）:**
   • 含锂电池产品 - 空运受限，物流成本增加30-50%
   • 液体/香水 - 运输受限，易泄漏
   • 易碎品/玻璃 - 破损率5-15%，售后成本高
   • 品牌仿品 - 100%查验风险，店铺可能被封

🚫 **绝对禁止品类:**
   • 电子烟/烟草制品 - 俄罗斯严格禁止跨境销售
   • 药品/保健品 - 需要认证，个人进口受限
   • 武器/刀具 - 违法产品，严重法律后果
   • 色情/成人用品 - 内容限制严格

🌟 **运营建议:**
   1. 优先选择无电池、非液体、非易碎的商品
   2. 冬季商品(9月-3月)销售旺季，提前备货
   3. 大件商品考虑本地仓发货，降低物流成本
   4. 俄罗斯消费者重视产品质量和包装
   5. 价格需考虑卢布汇率波动和关税
`);
console.log('='.repeat(60));