
import { ProductAnalyzer, type CompetitorInfo } from "./src/services/product-analyzer.js";
import { PricingEngine } from "./src/services/pricing-engine.js";
import { calculateProfit, calculateSuggestedPrice } from "./src/services/profit-calc.js";

interface TestProduct {
  sourceUrl: string;
  title: string;
  categoryPath: string[];
  price: { currentMin: number; currentMax: number };
  specifications?: { weightKg?: number };
}

const testProducts: TestProduct[] = [
  {
    sourceUrl: "https://detail.1688.com/offer/100001.html",
    title: "无线蓝牙耳机 TWS降噪 迷你入耳式",
    categoryPath: ["数码", "耳机", "无线耳机"],
    price: { currentMin: 80, currentMax: 120 },
    specifications: { weightKg: 0.15 }
  },
  {
    sourceUrl: "https://detail.1688.com/offer/100002.html",
    title: "智能手表 多功能运动手环 心率监测",
    categoryPath: ["数码", "智能穿戴", "智能手表"],
    price: { currentMin: 120, currentMax: 180 },
    specifications: { weightKg: 0.25 }
  },
  {
    sourceUrl: "https://detail.1688.com/offer/100003.html",
    title: "便携折叠充电宝 20000mAh 大容量",
    categoryPath: ["数码", "移动电源", "充电宝"],
    price: { currentMin: 60, currentMax: 90 },
    specifications: { weightKg: 0.35 }
  },
  {
    sourceUrl: "https://detail.1688.com/offer/100004.html",
    title: "USB-C快充数据线 编织线 1米",
    categoryPath: ["数码配件", "数据线"],
    price: { currentMin: 8, currentMax: 15 },
    specifications: { weightKg: 0.05 }
  },
  {
    sourceUrl: "https://detail.1688.com/offer/100005.html",
    title: "便携蓝牙音箱 户外防水 重低音",
    categoryPath: ["数码", "音频", "蓝牙音箱"],
    price: { currentMin: 50, currentMax: 80 },
    specifications: { weightKg: 0.4 }
  }
];

const competitorsData = new Map<string, CompetitorInfo[]>();

competitorsData.set("https://detail.1688.com/offer/100001.html", [
  { productId: 2001, priceRub: 1999, rating: 4.6, reviewCount: 850, salesVolume: 3500, title: "JBL无线蓝牙耳机" },
  { productId: 2002, priceRub: 1599, rating: 4.3, reviewCount: 1200, salesVolume: 5000, title: "国产TWS蓝牙耳机" },
  { productId: 2003, priceRub: 2299, rating: 4.8, reviewCount: 650, salesVolume: 2800, title: "降噪耳机旗舰版" },
  { productId: 2004, priceRub: 1299, rating: 4.1, reviewCount: 2100, salesVolume: 8500, title: "平价蓝牙耳机" }
]);

competitorsData.set("https://detail.1688.com/offer/100002.html", [
  { productId: 3001, priceRub: 2999, rating: 4.7, reviewCount: 600, salesVolume: 2500, title: "品牌智能手表" },
  { productId: 3002, priceRub: 1899, rating: 4.2, reviewCount: 1500, salesVolume: 6000, title: "国产运动智能手表" }
]);

competitorsData.set("https://detail.1688.com/offer/100003.html", [
  { productId: 4001, priceRub: 899, rating: 4.5, reviewCount: 2500, salesVolume: 10000, title: "品牌充电宝 20000mAh" },
  { productId: 4002, priceRub: 699, rating: 4.0, reviewCount: 3500, salesVolume: 15000, title: "平价大容量充电宝" }
]);

competitorsData.set("https://detail.1688.com/offer/100004.html", [
  { productId: 5001, priceRub: 299, rating: 4.4, reviewCount: 5000, salesVolume: 20000, title: "编织快充数据线" }
]);

competitorsData.set("https://detail.1688.com/offer/100005.html", [
  { productId: 6001, priceRub: 1299, rating: 4.3, reviewCount: 1800, salesVolume: 7500, title: "便携户外蓝牙音箱" },
  { productId: 6002, priceRub: 1699, rating: 4.6, reviewCount: 1200, salesVolume: 5000, title: "高端防水蓝牙音箱" }
]);

const analyzer = new ProductAnalyzer(12.5);
const pricingEngine = new PricingEngine();

console.log("========================================");
console.log("          📊 功能测试 - 选品分析        ");
console.log("========================================\n");

const analyses = testProducts.map(product => {
  const competitors = competitorsData.get(product.sourceUrl) || [];
  return analyzer.analyzeProduct(
    product as unknown as Parameters<typeof analyzer.analyzeProduct>[0],
    competitors,
    { weightKg: product.specifications?.weightKg || 0.3 }
  );
});

const recommendedProducts = analyses.filter(a => a.suggested);
const notRecommendedProducts = analyses.filter(a => !a.suggested);

console.log(`📈 分析总数: ${analyses.length}`);
console.log(`✅ 推荐上架: ${recommendedProducts.length}`);
console.log(`❌ 不推荐: ${notRecommendedProducts.length}`);
console.log();

analyses.forEach((analysis, index) => {
  const statusIcon = analysis.suggested ? '✅' : '⚠️';
  console.log(`${statusIcon} 商品 ${index + 1}: ${analysis.title}`);
  console.log(`   采购成本: ¥${analysis.priceCny}  →  总成本: ₽${analysis.totalCostRub}`);
  console.log(`   建议售价: ₽${analysis.estimatedPriceRub}  →  利润率: ${(analysis.profitMargin * 100).toFixed(1)}%`);
  console.log(`   竞争程度: ${analysis.competitionLevel === 'low' ? '低' : analysis.competitionLevel === 'medium' ? '中' : '高'}  |  市场趋势: ${analysis.trend === 'up' ? '📈 上升' : analysis.trend === 'stable' ? '➡️ 稳定' : '📉 下降'}`);
  console.log(`   综合评分: ${analysis.score}/100`);
  console.log(`   ${analysis.recommendation}`);
  console.log();
});

console.log("========================================");
console.log("         💰 功能测试 - 动态定价         ");
console.log("========================================\n");

const positionLabels = {
  'below_avg': '低于市场平均',
  'at_avg': '市场平均水平',
  'above_avg': '高于市场平均'
};

testProducts.forEach((product, index) => {
  const competitors = competitorsData.get(product.sourceUrl) || [];
  const weightKg = product.specifications?.weightKg || 0.3;
  
  console.log(`📦 商品 ${index + 1}: ${product.title}`);
  console.log(`   采购成本: ¥${product.price.currentMin} | 重量: ${weightKg}kg | 汇率: 12.5`);
  
  if (competitors.length > 0) {
    const avgPrice = Math.round(competitors.reduce((sum, c) => sum + c.priceRub, 0) / competitors.length);
    console.log(`   竞品数量: ${competitors.length} | 竞品均价: ₽${avgPrice}`);
  }
  
  const strategies: Array<'leader' | 'middle' | 'premium'> = ['leader', 'middle', 'premium'];
  
  strategies.forEach(position => {
    const result = pricingEngine.calculatePrice(
      product.price.currentMin,
      12.5,
      competitors,
      { desiredPosition: position, discountEnabled: false, weightKg }
    );
    
    const label = position === 'leader' ? '🏆 价格领先' : position === 'premium' ? '💎 溢价策略' : '📊 市场跟随';
    
    if (result.isFeasible) {
      console.log(`   ${label}: ₽${result.finalPriceRub} (利润${(result.margin * 100).toFixed(1)}%, ${positionLabels[result.pricePosition]})`);
    } else {
      console.log(`   ${label}: ⚠️ ${result.feasibilityNote}`);
    }
  });
  console.log();
});

console.log("========================================");
console.log("         📈 功能测试 - 利润计算         ");
console.log("========================================\n");

testProducts.forEach((product, index) => {
  const weightKg = product.specifications?.weightKg || 0.3;
  const competitors = competitorsData.get(product.sourceUrl) || [];
  const avgCompetitorPrice = competitors.length > 0
    ? Math.round(competitors.reduce((sum, c) => sum + c.priceRub, 0) / competitors.length)
    : Math.round(product.price.currentMin * 12.5 * 1.5);
  
  const result = calculateProfit({
    costCny: product.price.currentMin,
    sellingPriceRub: avgCompetitorPrice,
    exchangeRate: 12.5,
    weightKg
  });
  
  console.log(`📦 商品 ${index + 1}: ${product.title}`);
  console.log(`   采购成本: ¥${result.costCny}`);
  console.log(`   🔖 成本明细:`);
  console.log(`     - 商品成本: ₽${result.breakdown.productCost}`);
  console.log(`     - 运费: ₽${result.breakdown.shippingCost}`);
  console.log(`     - 包装: ₽${result.breakdown.packagingCost}`);
  console.log(`     - 平台费(15%): ₽${result.breakdown.platformFee}`);
  console.log(`   💰 总成本: ₽${result.totalCostRub}`);
  console.log(`   📊 按竞品均价₽${result.sellingPriceRub}销售:`);
  
  if (result.grossProfitRub > 0) {
    console.log(`     ✨ 毛利润: ₽${result.grossProfitRub} (利润率${result.marginPercent}%)`);
  } else {
    console.log(`     ❌ 亏损: ₽${result.grossProfitRub} (利润率${result.marginPercent}%) - 建议提高售价或选更低成本的产品`);
  }
  console.log();
});

console.log("========================================");
console.log("         🎯 功能测试 - 建议售价         ");
console.log("========================================\n");

const targetMargins = [0.2, 0.3, 0.45];

testProducts.forEach((product, index) => {
  const weightKg = product.specifications?.weightKg || 0.3;
  console.log(`📦 商品 ${index + 1}: ${product.title}`);
  console.log(`   采购成本: ¥${product.price.currentMin} | 重量: ${weightKg}kg`);
  console.log();
  
  targetMargins.forEach(margin => {
    const suggestedPrice = calculateSuggestedPrice(
      product.price.currentMin,
      12.5,
      margin,
      weightKg
    );
    const profit = Math.round(suggestedPrice - product.price.currentMin * 12.5);
    
    console.log(`   🎯 目标利润率${(margin * 100).toFixed(0)}%:`);
    console.log(`      - 建议售价: ₽${suggestedPrice}`);
    console.log(`      - 预计利润: ₽${profit}/件`);
  });
  console.log();
});

console.log("========================================");
console.log("         📊 功能测试 - API示例         ");
console.log("========================================\n");

console.log("📝 你可以通过以下API调用使用这些功能：");
console.log();
console.log("1️⃣  选品分析 API:");
console.log("   POST /api/analyze/analyze");
console.log("   Body: { products: [...], competitors: [...], options: {...} }");
console.log();
console.log("2️⃣  动态定价 API:");
console.log("   POST /api/analyze/pricing");
console.log("   Body: { costCny: 80, exchangeRate: 12.5, competitors: [...] }");
console.log();
console.log("3️⃣  批量定价 API:");
console.log("   POST /api/analyze/batch-pricing");
console.log("   Body: { products: [...], exchangeRate: 12.5, options: {...} }");
console.log();
console.log("========================================");
console.log("              ✅ 测试完成                ");
console.log("========================================\n");