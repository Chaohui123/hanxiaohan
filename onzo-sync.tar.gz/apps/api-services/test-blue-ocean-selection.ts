import { batchAnalyzeBlueOcean, getOnzoSalesTrends, getTopBlueOceanCategories, getKeywordRecommendations } from './src/services/blue-ocean-analyzer.js';
import type { ScrapedProduct } from '@onzo/shared-types';

function makeProduct(id: string, title: string, price: number, category: string[], weight: number, desc: string): ScrapedProduct {
  return {
    id,
    source: 'test',
    sourceUrl: `https://test.com/${id}`,
    sourceId: id,
    title,
    description: desc,
    categoryPath: category,
    price: { currentMin: price, currentMax: price, original: price, currency: 'CNY' },
    images: [],
    specifications: { '重量': weight.toString(), 'weight': weight.toString() },
    createdAt: new Date(),
    updatedAt: new Date(),
    status: 'active'
  } as ScrapedProduct;
}

console.log('\n' + '='.repeat(80));
console.log('🎯 Onzo 俄罗斯市场 蓝海选品系统 测试');
console.log('='.repeat(80));
console.log('\n📍 时间: ' + new Date().toLocaleString('zh-CN'));
console.log('📍 当前月份: ' + (new Date().getMonth() + 1) + '月');

console.log('\n' + '='.repeat(80));
console.log('📊 一、Onzo平台历史热销趋势分析');
console.log('='.repeat(80));
const trends = getOnzoSalesTrends();
trends.slice(0, 8).forEach((t, i) => {
  const growthIcon = t.salesGrowth >= 40 ? '🚀' : t.salesGrowth >= 25 ? '📈' : '➡️';
  console.log(`\n${i + 1}. ${t.category} ${growthIcon}`);
  console.log(`   增长: +${t.salesGrowth}%  |  均价: ₽${t.avgPriceRub}  |  利润: ${(t.avgProfitMargin * 100).toFixed(0)}%  |  上架数: ${t.listingCount}`);
  console.log(`   热词: ${t.hotKeywords.slice(0, 5).join('、')}`);
  console.log(`   建议: ${t.recommendation}`);
});

console.log('\n' + '='.repeat(80));
console.log('🏆 二、当前蓝海品类推荐');
console.log('='.repeat(80));
const topCats = getTopBlueOceanCategories();
topCats.slice(0, 10).forEach((c, i) => {
  const icon = c.score >= 90 ? '🌟' : c.score >= 80 ? '⭐' : '✨';
  console.log(`${icon} ${i + 1}. ${c.category} - 评分${c.score}/100`);
  console.log(`   ${c.why}\n`);
});

console.log('\n' + '='.repeat(80));
console.log('🔑 三、选品关键词指南');
console.log('='.repeat(80));
const kwRecs = getKeywordRecommendations();
kwRecs.forEach(group => {
  console.log(`\n${group.type}`);
  console.log(`   关键词: ${group.keywords.join('、')}`);
  console.log(`   ${group.tips}`);
});

console.log('\n' + '='.repeat(80));
console.log('🎨 四、测试商品批量分析');
console.log('='.repeat(80));

const testProducts: ScrapedProduct[] = [
  makeProduct('p1', '冬季保暖羽绒服 白鸭绒填充 加厚防水', 180, ['服装', '男装', '羽绒服'], 1.2, '俄罗斯寒冷地区必备 加厚保暖 防水面料'),
  makeProduct('p2', '汽车机油滤清器 通用滤芯 保养耗材', 25, ['汽车', '保养'], 0.3, '俄罗斯车主80%自行更换 高频复购耗材 质量稳定'),
  makeProduct('p3', '汽车脚垫 防水防滑 定制款', 80, ['汽车', '内饰'], 0.8, '新车必备 易清洁 防水防滑 定制尺寸'),
  makeProduct('p4', '多功能螺丝刀套装 精密维修工具', 35, ['工具', '五金'], 0.5, '俄罗斯DIY文化 家庭维修必备 高碳钢材质'),
  makeProduct('p5', '收纳盒 多功能整理箱 衣柜收纳', 25, ['家居', '收纳'], 0.6, '俄式住宅收纳需求大 多规格 防尘防潮'),
  makeProduct('p6', '汽车应急包 搭电线 拖车绳 安全锤', 60, ['汽车', '应急'], 1.5, '车主必备安全品 应急救援 高性价比'),
  makeProduct('p7', '蓝牙耳机 无线降噪 入耳式', 50, ['数码', '耳机'], 0.15, '蓝牙5.0 主动降噪 长续航 迷你便携'),
  makeProduct('p8', '玻璃香水瓶 水晶装饰摆件', 30, ['家居', '装饰'], 1.0, '玻璃材质 易碎品 注意包装运输'),
  makeProduct('p9', '电子烟 加热不燃烧 尼古丁烟油', 100, ['烟具'], 0.2, '含尼古丁产品 跨境受限'),
  makeProduct('p10', '雪地靴 加绒保暖 防滑防水', 120, ['鞋靴', '女鞋'], 1.0, '俄罗斯冬季必备 加绒加厚 防滑大底'),
  makeProduct('p11', '清洁抹布 魔术海绵擦 百洁布', 8, ['家居', '清洁'], 0.2, '高频消耗品 复购强 轻小件易发货'),
  makeProduct('p12', '智能手表 心率监测 多功能运动手环', 100, ['数码', '智能穿戴'], 0.25, '心率监测 睡眠监测 蓝牙连接 时尚外观'),
  makeProduct('p13', '汽车玻璃水 防冻浓缩液 冬季专用', 15, ['汽车', '保养'], 0.8, '冬季刚需 防冻除冰 浓缩液体注意物流'),
  makeProduct('p14', '厨房密封胶 防霉防水 厨卫专用', 12, ['五金', '维修'], 0.4, '家庭装修维修必备 防水防霉 多色可选'),
  makeProduct('p15', '耐克同款运动鞋 跑步鞋 复刻版', 85, ['鞋靴', '运动'], 0.7, '注意品牌风险 可能被海关查扣'),
  makeProduct('p16', '户外帐篷 3-4人野营 防水防风', 150, ['户外', '露营'], 3.0, '夏季户外旺季 防水涂层 快速搭建'),
  makeProduct('p17', '汽车方向盘套 真皮 防滑透气', 35, ['汽车', '内饰'], 0.4, '方向盘装饰 真皮手感 防滑透气 易安装'),
  makeProduct('p18', '保温杯 304不锈钢 大容量保温壶', 45, ['家居', '日用品'], 0.5, '俄罗斯冬季必备 保温12小时 304不锈钢'),
  makeProduct('p19', 'LED汽车大灯 超亮改装灯泡', 40, ['汽车', '电子'], 0.3, 'LED节能 高亮度 易安装 DIY更换'),
  makeProduct('p20', '折叠充电电钻 多功能家用电动螺丝刀', 75, ['工具', '电动'], 1.2, '锂电池充电 家用维修好帮手 注意含电池'),
];

console.log(`\n📦 共分析 ${testProducts.length} 款商品\n`);

const competitors = new Map<string, { priceRub: number; salesVolume?: number }[]>();
testProducts.forEach((p, i) => {
  const numCompetitors = [3, 8, 12, 5, 10, 2, 15, 6, 4, 7, 3, 20, 5, 2, 18, 4, 6, 9, 8, 11][i];
  const comps: { priceRub: number; salesVolume?: number }[] = [];
  const basePrice = p.price.currentMin * 13;
  for (let j = 0; j < numCompetitors; j++) {
    comps.push({ priceRub: Math.round(basePrice * (0.8 + Math.random() * 0.5)), salesVolume: Math.floor(Math.random() * 200) });
  }
  competitors.set(p.sourceUrl, comps);
});

const results = batchAnalyzeBlueOcean(testProducts, competitors, { exchangeRate: 12.5, defaultWeightKg: 0.5 });

console.log('\n' + '='.repeat(80));
console.log('🎯 五、蓝海选品分析结果');
console.log('='.repeat(80));
console.log(`\n📊 统计:`);
console.log(`   推荐上架: ${results.summary.recommendCount}款`);
console.log(`   可考虑上架: ${results.summary.considerCount}款`);
console.log(`   不推荐/风险: ${results.summary.rejectedCount}款`);
console.log(`   平均评分: ${results.summary.avgOverallScore}/100`);
console.log(`   热门标签: ${results.summary.topCategories.join('、')}`);
results.summary.seasonalTips.forEach(tip => console.log(`   🌟 ${tip}`));

console.log('\n' + '─'.repeat(80));
console.log('🌟 【强烈推荐 TOP 5】 综合评分 >= 85');
console.log('─'.repeat(80));
results.recommended.slice(0, 5).forEach((r, i) => {
  console.log(`\n${i + 1}. ${r.product.title}`);
  console.log(`   💰 成本¥${r.product.price.currentMin} → 建议售价₽${r.recommendedPriceRub}，利润₽${r.estimatedProfitPerUnit}/件`);
  console.log(`   📊 综合评分: ${r.overallScore}/100  |  标签: ${r.categoryTags.length > 0 ? r.categoryTags.join('、') : '无'}`);
  console.log(`   📈 细分评分: 需求${r.score.marketDemand} 利润${r.score.profitPotential} 竞争${r.score.competitionLevel} DIY${r.score.diyFriendliness} 物流${r.score.logisticsFriendliness}`);
  r.strengths.forEach(s => console.log(`   ${s}`));
  r.actionItems.slice(0, 2).forEach(a => console.log(`   ${a}`));
});

console.log('\n' + '─'.repeat(80));
console.log('✅ 【推荐上架】 评分 65-84');
console.log('─'.repeat(80));
results.recommended.slice(5).forEach((r, i) => {
  console.log(`${i + 6}. ${r.product.title.substring(0, 40)}... | 评分${r.overallScore} | 售价₽${r.recommendedPriceRub} | 利润₽${r.estimatedProfitPerUnit}`);
});

if (results.consider.length > 0) {
  console.log('\n' + '─'.repeat(80));
  console.log('🤔 【可考虑】 需优化后再上架');
  console.log('─'.repeat(80));
  results.consider.slice(0, 5).forEach((r, i) => {
    console.log(`${i + 1}. ${r.product.title.substring(0, 40)}... | 评分${r.overallScore} | ${r.weaknesses.slice(0, 2).map(w => w.replace(/[⚠️📦⚔️❌⚖️📅🔄]/g, '').trim()).join('、')}`);
  });
}

console.log('\n' + '─'.repeat(80));
console.log('❌ 【不推荐/高风险】 请避免');
console.log('─'.repeat(80));
results.rejected.slice(0, 8).forEach((r, i) => {
  console.log(`${i + 1}. ${r.product.title.substring(0, 40)}... | 评分${r.overallScore}`);
  r.weaknesses.slice(0, 2).forEach(w => console.log(`   ${w}`));
});

console.log('\n' + '='.repeat(80));
console.log('💡 六、新店运营策略建议');
console.log('='.repeat(80));

console.log(`
🎯 【第一阶段：快速起步（1-3个月）】
   1. 优先选择【蓝海推荐TOP5】类商品上架
   2. 聚焦汽车保养耗材、家居清洁、家庭维修工具3个方向
   3. 每款商品初期备货5-20件，降低试错成本
   4. 目标：第一个月上架15-25款商品，利润率统一40%+

📦 【第二阶段：扩大品类（3-6个月）】
   1. 根据销售数据增加高复购商品的库存深度
   2. 拓展冬季服装、鞋靴等高客单价品类
   3. 开始测试汽车内饰装饰类商品
   4. 目标：月销100+订单，稳定利润

💰 【第三阶段：精细化运营（6个月+）】
   1. 分析数据，砍掉低销量低利润商品
   2. 针对爆款深入开发同款不同色/款
   3. 考虑部分热销品本地仓备货
   4. 目标：月销500+，店铺评分4.5+

⚠️ 【红线：绝对不要碰】
   1. 电子烟/烟草制品 → 100%禁止
   2. 药品保健品 → 需要特殊审批
   3. 仿品/复刻 → 高风险被查
   4. 纯玻璃/陶瓷制品 → 破损率太高
   5. 带大锂电池的大件 → 物流成本爆炸

🌟 【核心成功要素】
   1. 选品质量 > 数量（精而不滥）
   2. 利润率40%+才能覆盖所有成本
   3. 优先选无电池、非液体、非易碎品
   4. 关注俄罗斯本土的消费习惯
   5. 季节品提前2-3个月备货
`);

console.log('\n' + '='.repeat(80));
console.log('🎉 测试完成！蓝海选品系统已准备就绪');
console.log('='.repeat(80));
console.log('\n💡 系统特点总结:');
console.log('   ✅ 俄罗斯本地市场需求分析');
console.log('   ✅ 汽配DIY友好度评分');
console.log('   ✅ 季节性时间窗口提示');
console.log('   ✅ 多维度蓝海评分(10项指标)');
console.log('   ✅ 自动定价和利润计算');
console.log('   ✅ 风险预警和合规检查');
console.log('   ✅ 操作建议和行动计划');
console.log('');