
export interface ApiConfig {
  apiBase: string;
  apiKey: string;
}

async function api<T>(config: ApiConfig, method: string, path: string, body?: unknown): Promise<T> {
  const url = `${config.apiBase}${path}`;
  const headers: Record<string, string> = {
    "X-API-Key": config.apiKey,
    "Content-Type": "application/json",
  };
  const resp = await fetch(url, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
    signal: AbortSignal.timeout(30_000),
  });
  if (!resp.ok) {
    const text = await resp.text().catch(() => "");
    throw new Error(`API ${resp.status}: ${text.slice(0, 200)}`);
  }
  return resp.json() as Promise<T>;
}

export const apiClient = {
  health: (c: ApiConfig) => api<Record<string, unknown>>(c, "GET", "/health"),
  ready: (c: ApiConfig) => api<Record<string, unknown>>(c, "GET", "/ready"),
  diagnose: (c: ApiConfig) => api<Record<string, unknown>>(c, "GET", "/api/diagnose"),
  dashboard: (c: ApiConfig) => api<Record<string, unknown>>(c, "GET", "/api/dashboard"),
  orders: (c: ApiConfig, status?: string) =>
    api<Record<string, unknown>>(c, "GET", `/api/orders${status ? `?status=${status}` : ""}`),
  inventoryAlerts: (c: ApiConfig) => api<Record<string, unknown>>(c, "GET", "/api/inventory/alerts"),
  llmStats: (c: ApiConfig) => api<Record<string, unknown>>(c, "GET", "/api/stats/llm"),
  taskStats: (c: ApiConfig) => api<Record<string, unknown>>(c, "GET", "/api/task/queue/stats"),
  syncOrders: (c: ApiConfig) => api<Record<string, unknown>>(c, "POST", "/api/orders/sync"),
  backup: (c: ApiConfig) => api<Record<string, unknown>>(c, "POST", "/api/db/backup"),
  reconcile: (c: ApiConfig, dateFrom: string, dateTo: string) =>
    api<Record<string, unknown>>(c, "POST", "/api/orders/reconcile", { dateFrom, dateTo }),
  pipelineHealth: (c: ApiConfig) => api<Record<string, unknown>>(c, "GET", "/ready/pipeline"),
};
